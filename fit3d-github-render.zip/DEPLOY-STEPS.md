# Fit3D - GitHub + Render par live karne ke steps

## Step 1: GitHub repo banao
1. github.com par login karo -> `+` -> New repository.
2. Naam: `fit3d`, **Private** chuno, README/gitignore tick mat karo -> Create repository.
3. "uploading an existing file" par click karo.
4. Is zip ko extract karke uske ANDAR ki saari files (Ctrl+A) drag karke upload karo.
   (zip ka folder nahi, uske andar ki files: package.json, src, public, render.yaml ... repo ke root mein honi chahiye)
5. Commit changes dabao.

## Step 2: Render par live karo
1. render.com par GitHub se login karo.
2. New + -> Blueprint -> apna `fit3d` repo connect karo.
3. Render `render.yaml` apne aap padh lega (fit3d-web, Static Site) -> Apply dabao.
4. Build 3-6 minute leta hai. "Live" dikhe to link kholo: https://fit3d-web.onrender.com (naam alag bhi ho sakta hai).

## Step 3: Firebase login ke liye
1. console.firebase.google.com -> Authentication -> Settings -> Authorized domains.
2. Render ka address (jaise fit3d-web.onrender.com) add karo.
   Ye tabhi zaroori hai jab app mein Google login use ho.

## Baad mein badlav karna
GitHub mein kisi file ko edit karke Commit karo -> Render apne aap website update kar deta hai.
